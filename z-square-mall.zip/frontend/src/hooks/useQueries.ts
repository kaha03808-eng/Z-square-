// No backend queries needed for this static website
export {};
