# Specification

## Summary
**Goal:** Update the text label of the Facebook social media link in the Footer to display "Hasnain".

**Planned changes:**
- Change the visible text of the first social media anchor element (Facebook link) in the Footer component to "Hasnain"

**User-visible outcome:** The Facebook link in the footer now displays "Hasnain" as its label, while retaining its existing styling and behavior.
